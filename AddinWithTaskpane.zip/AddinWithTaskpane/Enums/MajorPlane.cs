﻿namespace AddinWithTaskpane
{
    /// <summary>
    /// Enum of planes
    /// </summary>
    public enum MajorPlane
    {
        Front = 1,
        Top = 2,
        Right = 3
    }
}
