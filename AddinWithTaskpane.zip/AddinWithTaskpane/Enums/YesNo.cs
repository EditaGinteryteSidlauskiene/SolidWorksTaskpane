﻿namespace AddinWithTaskpane
{
    /// <summary>
    /// Enum for yes/no
    /// </summary>
    public enum YesNo
    {
        Yes,
        No
    }
}
