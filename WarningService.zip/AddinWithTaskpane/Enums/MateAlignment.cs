﻿namespace AddinWithTaskpane
{
    public enum MateAlignment
    {
        Aligned,
        Anti_Aligned,
        Closest
    }
}
